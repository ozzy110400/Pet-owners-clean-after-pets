import React from 'react';
import {BodyBlock} from "./components/BodyBlock";
import {Box} from "@mui/material";
import dog from './components/images/dog.webp';

function App() {
  return (
    <div className="App">
     <Box sx={{
         height: '160px',
         width: '100%',
         fontSize: { xs: 82, sm: 120 },
         alignItems: 'center',
         display: 'flex',
         justifyContent: 'center',
         fontWeight: 800,
         backgroundColor: 'black',
         color: 'white',
         paddingTop: 4,
     }}>
         U<span style={{ color: '#dffe5f' }}>it</span>pe
         <img src={dog} alt={dog} style={{ height: '100px', marginLeft: '12px', marginBottom: '12px' }} />
     </Box>
     <BodyBlock type='ABOUT US' />
     <BodyBlock type='DEMO' />
     <BodyBlock type='OUR TEAM' />
    </div>
  );
}

export default App;
