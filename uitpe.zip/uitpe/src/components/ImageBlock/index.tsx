import {Stack} from "@mui/material";
import {TeamMember} from "../TeamMember";

export const ImageBlock: React.FC = () => {
    return (
        <Stack
            spacing={2}
            direction={{xs: 'column', lg: 'row' }}
            sx={{ maxWidth: 'calc(100% - 8px)', height: 'auto'}}
            >
            <TeamMember type={"ola"} />
            <TeamMember type={"alim"} />
            <TeamMember type={"nurba"} />
        </Stack>
    )
};