import {Box, Grid, Typography} from "@mui/material";

export const InfoGrid: React.FC = () => {
    return (
        <Box sx={{ flexGrow: 1 }}>
            <Grid container sx={{width: '100%', margin: 0, padding: 0}}>
                <Grid item xs={12} sx={{
                    border: '4px solid black',
                    backgroundColor: '#dffe5f',
                    color: 'black',
                    wordWrap: 'break-word',
                    minWidth: 'calc(33% - 12px)',
                    marginBottom: 3,
                }}>
                    <Typography sx={{padding: 3, fontSize: {xs: 24, sm: 32}}}>
                        Отходы жизнедеятельности собак крайне токсичный и опасны для окружающей среды, из-за наличия вредных бактерий и паразитов в них
                    </Typography>
                </Grid>
                <Grid item xs={12} sx={{
                    border: '4px solid black',
                    backgroundColor: '#dffe5f',
                    color: 'black',
                    wordWrap: 'break-word',
                    minWidth: 'calc(33% - 12px)',
                    marginBottom: 3,
                }}>
                    <Typography sx={{padding: 3, fontSize: {xs: 24, sm: 32}}}>
                        Не соблюдение закона РК от 30-го декабря 2021-го года
                        “Об ответственном обращении с животными” пункту 9, статьи 21.
                    </Typography>
                </Grid>
                <Grid item xs={12} sx={{
                    border: '4px solid black',
                    backgroundColor: '#dffe5f',
                    color: 'black',
                    wordWrap: 'break-word',
                    minWidth: 'calc(33% - 12px)',
                    marginBottom: 3,
                }}>
                    <Typography sx={{padding: 3, fontSize: {xs: 24, sm: 32}}}>
                        Проблема отслежвания людей и их собак, выражаемая только
                        в наличии возможности присмотра в реальном времени
                    </Typography>
                </Grid>
            </Grid>
        </Box>
    )
};