import {Box, Divider, Typography} from "@mui/material";
import {InfoBlock} from "../InfoBlock";
import {InfoGrid} from "../InfoGrid";
import {ImageBlock} from "../ImageBlock";
import video from '../images/video.mp4';
import result from '../images/results.png';
import cnn1 from '../images/cnn1.jpg';
import cnn2 from '../images/cnn2.jpg';

interface Props {
    type: 'ABOUT US' | 'DEMO' | 'OUR TEAM';
}

export type headline = 'ABOUT US' | 'DEMO' | 'OUR TEAM';

const TYPE_TEXT: Record<headline, string> = {
    "ABOUT US": 'О НАС',
    "DEMO": 'ИМПЛЕМЕНТАЦИЯ',
    "OUR TEAM": 'НАША КОМАНДА',
};

export const BodyBlock: React.FC<Props> = ({type}) => {
  return (
    <Box sx={{color: type === 'DEMO' ? 'white' : 'black', backgroundColor: type === 'DEMO' ? 'black' : 'white',
    paddingBottom: type === 'OUR TEAM' ? 4 : 0  }}>
      <Divider sx={{ bgcolor: '#dffe5f', marginLeft: -6, marginRight: 0}} />
      <Box sx={{padding: '32px 260px'}}>
        <Typography sx={{
            height: 'auto',
            backgroundClip: 'content-box',
            width: '100%',
            fontSize: { xs: 46, sm: 72 },
            alignItems: 'start',
            display: 'flex',
            fontWeight: 800,
            flexDirection: 'column',
            justifyContent: 'start',
        }}>
            {TYPE_TEXT[type]}
            <InfoBlock type={type}/>
            {type === 'ABOUT US' && (
                <>
                    <Typography sx={{
                        fontSize: { xs: 36, sm: 52 },
                        marginBottom: 2,
                    }}>
                        ПОЧЕМУ ЭТО ВАЖНО?
                    </Typography>
                    <InfoGrid />
                </>
            )}
            {type === 'DEMO' &&
                (
                <>
                    <Box>
                        <img style={{width:'100%'}} src={cnn1} alt={cnn1} />
                        <img style={{width:'100%'}} src={cnn2} alt={cnn2} />
                        <img style={{width:'100%'}} src={result} alt={result} />
                    </Box>
                    <p style={{margin: 0}}>ДЕМО</p>
                    <video src={video} width="100%" height="auto" controls/>
                </>
                )
            }
            {type === 'OUR TEAM' &&
                <ImageBlock />
            }
        </Typography>
      </Box>
    </Box>
  )
};