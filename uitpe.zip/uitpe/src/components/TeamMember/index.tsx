import {Box} from "@mui/material";
import ola from '../images/ola.jpg';
import alim from '../images/alim.jpg';
import nurba from '../images/nurba.jpg';

interface Props {
    type: 'nurba' | 'alim' | 'ola';
}

export const TeamMember: React.FC<Props> = ({type}) => {
    return (
        <Box sx={{width: 'calc(33%)' }}>
            {
                type === 'nurba' &&
                <img src={nurba} alt='nurba' style={{ border: '4px solid black', maxHeight: '288px', width: '100%', objectFit: 'cover'}} />
            }
            {
                type === 'alim' &&
                <img src={alim} alt='alim' style={{ border: '4px solid black', maxHeight: '288px', width: '100%', objectFit: 'cover'}}/>
            }
            {
                type === 'ola' &&
                <img src={ola} alt='ola' style={{ border: '4px solid black', maxHeight: '288px', width: '100%', objectFit: 'cover'}}/>
            }
            <Box sx={{
                border: '4px solid black',
                backgroundColor: '#dffe5f',
                color: 'black',
                wordWrap: 'break-word',
                width: '100%',
                fontSize: '24px',
            }}>
                {type === 'ola' && <>Олжас Ергали, Data Scientist</>}
                {type === 'alim' && <>Алимжан Кайырлы, Data Scientist</>}
                {type === 'nurba' && <>Нурбек Жомартов, Frontend Dev</>}
            </Box>
        </Box>
    )
};