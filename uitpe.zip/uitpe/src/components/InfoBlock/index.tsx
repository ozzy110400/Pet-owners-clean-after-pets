import {Box} from "@mui/material";

interface Props {
    type: 'ABOUT US' | 'DEMO' | 'OUR TEAM';
}

export const InfoBlock: React.FC<Props> = ({type}) => {
    return (
        <Box sx={{
            marginTop: {xs: 2, sm: 0},
            border: '4px solid #dffe5f',
            backgroundColor: 'black',
            color: 'white',
            wordWrap: 'break-word',
            padding: 3,
            width: 'calc(100% - 55px)',
            marginBottom: 3,
            fontWeight: 400,
            fontSize: {xs: 24, sm: 32},
        }}>
            {type === 'ABOUT US' &&
                <Box>
                    Мы - молодая команда разработчиков, которая представляет к вашему вниманию
                    модель нейронной сети, которая определяет собак в процессе дефикации
                </Box>
            }
            {type === 'DEMO' &&
                <Box>
                    Наш подход заключается в комбинировании двух моделей -
                    YOLOv8 и ViT 16x16. Первая модель отвечает за real-time
                    детекцию собак в кадре, тем временем ViT отвечает за
                    распознавание действий конкретной собаки. Наша ключевая цель
                    - определить, занят ли объект процессом дефекации.
                    Наш подход способен с точностью в 95%-ов определить,
                    следует ли обратить внимание на конкретный случай или нет.
                </Box>
            }
            {type === 'OUR TEAM' &&
                <Box>
                    Состав Нашей Команды
                </Box>
            }
        </Box>
    )
};